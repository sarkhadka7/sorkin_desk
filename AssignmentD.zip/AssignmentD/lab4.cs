using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//sujan Bhandari
// yogendra adhikari
namespace Lab04
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 1, b = 2, c = 5;
            double x = 2.2, y = 4.4, z = 6.6, ans;
            ans = average(a, b);
            Console.WriteLine("average(a,b) = " + ans);
            ans = average(a, b, c);
            Console.WriteLine("average(a,b,c) = "+ ans);
            ans = average(x, y);
            Console.WriteLine("average(x,y) = " + ans);
            ans = average(x, y, z);
            Console.WriteLine("average(x,y,z) = " + ans);
            Console.ReadLine();
        }
        public static double average(double n1, double n2)
        {
            return (n1 + n2)/2.0;

        }  
        public static double average(double n1, double n2, double n3)
        {
            return (n1 + n2 + n3)/3.0;

        }
        // 1) No we do not need the int parameter if we have the double version already. Double version accepts all integer and double values. Where as integer version will only accept integer.

        // 2) No we do not but it would be clearer if we break it down to make it look simple.
        
        // 3) It is legal. The reason is that whatever the parameter type is it will try to convert them into double before going inside the function.

    }
}