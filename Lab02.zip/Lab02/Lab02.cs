﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab02
{
    class Lab02
    {
        static void Main(string[] args)
        {
            string response = null;
            char p = '0', type = '0';
            bool pres = false, glare = false;   // needed to initiate to get rid of errors.
            double prescribed_glass = 40.00;
            double non_prescribed = 25.00;
            double anti_glare = 12.50;
            double brown_tint = 9.99;
            double total;

            // Welcome line...
            Console.WriteLine("Welcome, Please select your choice of glasses.");

            // Asking prescription until right option.
            while (p != '1' && p != '2')
            {
                Console.Write("1 --> Precription, 2 --> non-prescription: ");
                response = Console.ReadLine();
                // stripping off the first character.
                p = response[0]; 
            }

            if (p == '1')
            {
                pres = true;
            }
            else
            {
                pres = false;
            }

            response = null;
            // Asking color type until the right option.
            while (type != '1' && type != '2')
            {
                Console.Write("1 --> anti-glare, 2 --> brown tint: ");
                response = Console.ReadLine();
                // stripping off the first character.
                type = response[0];
            }

            if (type == '1')
            {
                glare = true;
            }
            else
            {
                glare = false;
            }

            // Calculate options.
            if (pres)
            {
                if (glare)
                {
                    total = prescribed_glass + anti_glare; 
                }
                else
                {
                    total = prescribed_glass + brown_tint;
                }
            }
            else
            {
                if (glare)
                {
                    total = non_prescribed + anti_glare;
                }
                else
                {
                    total = non_prescribed + brown_tint;
                }
            }

            Console.WriteLine("Your total cost is $" + total);
            Console.ReadLine();

        }
    }
}
